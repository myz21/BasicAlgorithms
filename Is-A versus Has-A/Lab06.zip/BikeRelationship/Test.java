
public class Test  
{  
    public static void main(String[] args)  
    {  
        Pulsar myPulsar = new Pulsar();  
        myPulsar.setColor("BLACK");  
        myPulsar.setMaxSpeed(136);  
        myPulsar.bikeInfo();  
       myPulsar.PulsarStartDemo();  
    }  
} 