
public class Engine  
{  
    public void start()  
    {  
        System.out.println("Started:");  
    }  
    public void stop()  
    {  
        System.out.println("Stopped:");  
    }  
}  
