
public class Pulsar extends Bike  
{  
    public void PulsarStartDemo()  
    {  
        Engine PulsarEngine = new Engine();  
        PulsarEngine.stop();  
    }  
} 
