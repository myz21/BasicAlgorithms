
public class Registration {
	public final Person person;
	public final Society society;
	
	public Registration(Person person, Society society)
	{
		this.person = person;
		this.society = society;
	}
}
